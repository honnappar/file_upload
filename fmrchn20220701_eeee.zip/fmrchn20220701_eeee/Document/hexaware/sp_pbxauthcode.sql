USE [cdr_hexaware]
GO

/****** Object:  StoredProcedure [dbo].[sp_PbxAuthGen]    Script Date: 05/17/2012 15:56:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

create proc [dbo].[sp_PbxAuthGen]
(
	@extn		bigint,
	@extnlocation	varchar(20),
	@changeauth 	tinyint,
	@newauth	varchar(10),
	@changecos   	tinyint,
	@cosn 		varchar(5)
)
AS
BEGIN
	declare @message varchar(80)
	declare @command varchar(256)
	declare @command1 varchar(256)
	DECLARE @p_extnno bigint, @p_newauth varchar(10), @p_oldauth varchar(10), @p_cos varchar(5), @p_location varchar(20)
	declare @authlength int
	declare @enamelength int
	declare @pos int
	declare @splitloc varchar(150)
	set @authlength = 8

	IF EXISTS (select * from extension where extn_no= @extn)
	BEGIN
		IF @changeauth = 1
		BEGIN
			--- Add authcode 
			set @pos = 1
			while @pos <> 0	
			begin
				set @pos= charindex(',',@extnlocation)
				if @pos = 0
				begin
					set @splitloc= substring(@extnlocation, 1, len(@extnlocation))
				end
				else
				begin
					set @splitloc= substring(@extnlocation, 1, @pos-1)
					SET @extnlocation= substring(@extnlocation, @pos+1, len(@extnlocation)-@pos)
				end
				select @splitloc as splitLocation

				IF EXISTS (select * from pbx_authcode where auth_inuse = 0 and pbx_location = @splitloc)
				BEGIN
					IF NOT EXISTS (select * from extension where extn_no= @extn and (extn_auth is not null or len(extn_auth) != 0 or extn_auth != 0))
					BEGIN

						DECLARE curs_unusedauth scroll cursor for 
						select pbx_extnno, pbx_newauth, pbx_oldauth, pbx_cos, pbx_location from pbx_authcode where auth_inuse = 0 and pbx_location = @splitloc

						open curs_unusedauth
						FETCH first from curs_unusedauth into @p_extnno, @p_newauth, @p_oldauth, @p_cos, @p_location

						update pbx_authcode set pbx_extnno= @extn, pbx_oldauth= pbx_newauth, pbx_newauth= @newauth, auth_inuse= 1 where pbx_newauth= @p_newauth and pbx_location= @p_location

						set @command= 'CHANGE AUTH ' + space(@authlength - len(@p_newauth)) + @p_newauth  + ' TO ' + space(@authlength - len(@newauth)) + @newauth + ' OF EXTN ' + space(@authlength - len(@extn)) + convert(varchar, @extn)
						set @command1= convert(varchar, @newauth) + ' ' + convert(varchar, @extn) + ' AMAP1'

						insert into command (extn_no, command, type, pbx_location, comm_datetime) values(@extn, @command, 'C', @p_location, getdate())
						insert into command (extn_no, command, type, pbx_location, comm_datetime) values(@extn, @command1, 'U', @p_location, getdate())

						IF @changecos = 1
						BEGIN
							--- Add Class Of Service
							update extension set open_cos= @cosn where extn_no= @extn
							update pbx_authcode set pbx_cos = @cosn, pbx_open_cos= @cosn where pbx_newauth= @newauth

							select @command= 'SET COR OF AUTH ' + space(@authlength - len(@newauth)) + @newauth  + ' TO ' + @cosn

							insert into command (extn_no, command, type, pbx_location, comm_datetime) values(@extn, @command, 'C', @p_location, getdate())
						END
						close curs_unusedauth
						deallocate curs_unusedauth
					END
				END
				ELSE
				BEGIN
					set @message= 'No Free Authcode Available'
				END
			end		--- End while
			update extension set extn_oldauth= extn_auth, extn_auth= @newauth where extn_no= @extn

		END		---End Add Authcode
		IF @changeauth = 2
		BEGIN
			--- Change Authcode
			IF EXISTS (select * from extension where extn_no= @extn and (extn_auth is not null or len(extn_auth) != 0 or extn_auth != 0))
			BEGIN
				DECLARE curs_unusedauth scroll cursor for 
				select extn_no, extn_auth, extn_oldauth, open_cos, e_pbxlocation from extension where extn_no = @extn
				
				open curs_unusedauth
				FETCH first from curs_unusedauth into @p_extnno, @p_newauth, @p_oldauth, @p_cos, @p_location

				set @pos = 1
				while @pos <> 0	
				begin
					set @pos= charindex(',',@p_location)
					if @pos = 0 
					begin
						set @splitloc= substring(@p_location, 1, len(@p_location))
					end
					else
					begin
						set @splitloc= substring(@p_location, 1, @pos-1)
						SET @p_location= substring(@p_location, @pos+1, len(@p_location)-@pos)
					end
					select @splitloc as splitLocation

					update pbx_authcode set pbx_oldauth= pbx_newauth, pbx_newauth= @newauth where pbx_extnno= @extn and pbx_location= @splitloc

					set @command= 'CHANGE AUTH ' + space(@authlength - len(@p_newauth)) + @p_newauth  + ' TO ' + space(@authlength - len(@newauth)) + @newauth + ' OF EXTN ' + space(@authlength - len(@extn)) + convert(varchar, @extn)
					set @command1= convert(varchar, @newauth) + ' ' + convert(varchar, @extn) + ' AMAP1'

					insert into command (extn_no, command, type, pbx_location, comm_datetime) values(@extn, @command, 'C', @splitloc, getdate())
					insert into command (extn_no, command, type, pbx_location, comm_datetime) values(@extn, @command1, 'U', @splitloc, getdate())

					IF @changecos = 2
					BEGIN
						--- Change Class Of Service
						update extension set open_cos= @cosn where extn_no= @extn
						update pbx_authcode set pbx_cos = @cosn, pbx_open_cos= @cosn where pbx_newauth= @newauth

						select @command= 'SET COR OF AUTH ' + space(@authlength - len(@newauth)) + @newauth  + ' TO ' + @cosn

						insert into command (extn_no, command, type, pbx_location, comm_datetime) values(@extn, @command, 'C', @splitloc, getdate())
					END

				end
				update extension set extn_oldauth= extn_auth, extn_auth= @newauth where extn_no= @extn

				close curs_unusedauth
				deallocate curs_unusedauth
			END
			ELSE
			BEGIN
				set @message= 'no more authcode in chgauth'
			END

		END
		IF @changeauth = 3
		BEGIN
			--- Delete Authcode
			IF EXISTS (select * from pbx_authcode where auth_inuse = 1 and pbx_extnno= @extn)
			BEGIN
				DECLARE curs_unusedauth scroll cursor for
				select pbx_extnno, pbx_newauth, pbx_oldauth, pbx_cos, pbx_location from pbx_authcode where auth_inuse = 1 and pbx_extnno= @extn
				
				open curs_unusedauth
				FETCH first from curs_unusedauth into @p_extnno, @p_newauth, @p_oldauth, @p_cos, @p_location
				
				set @pos = 1
				while @pos <> 0	
				begin
					set @pos= charindex(',',@p_location)
					if @pos = 0 
					begin
						set @splitloc= substring(@p_location, 1, len(@p_location))
					end
					else
					begin
						set @splitloc= substring(@p_location, 1, @pos-1)
						SET @p_location= substring(@p_location, @pos+1, len(@p_location)-@pos)
					end
					select @splitloc as splitLocation
			
					update pbx_authcode set pbx_extnno= 99999999, auth_inuse= 0 where pbx_extnno= @extn and pbx_location= @splitloc
	
					set @command= 'SET COR OF AUTH ' + space(@authlength - len(@p_newauth)) + @p_newauth  + ' TO ' + @cosn
					--set @command1= @newauth + ' ' + @extn + ' ' + 'AMAP1'
	
					insert into command (extn_no, command, type, pbx_location, comm_datetime) values(@extn, @command, 'C', @splitloc, getdate())
					--insert into command (extn_no, command, type, comm_datetime) values(@extn, @command1, 'U', getdate())
				end
				update extension set extn_oldauth= extn_auth, extn_auth= NULL where extn_no = @extn

				close curs_unusedauth
				deallocate curs_unusedauth
			END
			ELSE
			BEGIN
				set @message= 'no more authcode in delauth'
			END
		END
		IF @changeauth = 0
		BEGIN
			--- Only select Change COS ---
			/*IF @changecos = 1
			BEGIN
				--- Add Class Of Service
				IF EXISTS (select * from pbx_authcode where auth_inuse = 0)
				BEGIN
					DECLARE curs_unusedauth scroll cursor for 
					select pbx_extnno, pbx_newauth, pbx_oldauth, pbx_cos from pbx_authcode where auth_inuse = 0

					open curs_unusedauth
					FETCH first from curs_unusedauth into @p_extnno, @p_newauth, @p_oldauth, @p_cos

					update extension set open_cos= @cosn where extn_no= @extn
					update pbx_authcode set pbx_cos= @cosn where pbx_newauth= @p_newauth

					select @command= 'CHANGE COR OF AUTH ' + @newauth  + ' TO ' + @cosn

					insert into command (extn_no, command, type, comm_datetime) values(@extn, @command, 'C', getdate())

					close curs_unusedauth
					deallocate curs_unusedauth
				END
				ELSE
				BEGIN
					set @message= 'no more authcode in chgcos'

				END
			END*/
			IF @changecos = 2
			BEGIN
				--- Change Class Of Service
				IF EXISTS (select * from pbx_authcode where auth_inuse = 1 and pbx_extnno= @extn)
				BEGIN

					set @pos = 1
					while @pos <> 0	
					begin
						set @pos= charindex(',',@extnlocation)
						if @pos = 0 
						begin
							set @splitloc= substring(@extnlocation, 1, len(@extnlocation))
						end
						else
						begin
							set @splitloc= substring(@extnlocation, 1, @pos-1)
							SET @extnlocation= substring(@extnlocation, @pos+1, len(@extnlocation)-@pos)
						end
						--select @splitloc as splitLocation

						DECLARE curs_unusedauth scroll cursor for 
						select pbx_extnno, pbx_newauth, pbx_oldauth, pbx_cos, pbx_location from pbx_authcode where auth_inuse = 1 and pbx_extnno= @extn and pbx_location= @splitloc
	
						open curs_unusedauth
						FETCH first from curs_unusedauth into @p_extnno, @p_newauth, @p_oldauth, @p_cos, @p_location

						update pbx_authcode set pbx_cos= @cosn, pbx_open_cos= @cosn where pbx_extnno= @extn
	
						select @command= 'SET COR OF AUTH ' + space(@authlength - len(@p_newauth)) + @p_newauth  + ' TO ' + @cosn
	
						insert into command (extn_no, command, type, pbx_location, comm_datetime) values(@extn, @command, 'C', @p_location ,getdate())
	
						close curs_unusedauth
						deallocate curs_unusedauth
	
					end	--- End While 	
					update extension set open_cos= @cosn where extn_no= @extn	

				END
				ELSE
				BEGIN
					select @message= 'no more authcode in chgcos'
					--- select @message			
				END			
			END
			/*IF @changecos = 3
			BEGIN
				--- Delete Class Of Service
			END*/

		END 
	END
END


GO

